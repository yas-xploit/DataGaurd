# Setting.py

from pathlib import Path
import re
import tkinter as tk
from tkinter import (
    Canvas, Button, PhotoImage, Frame, Scrollbar,
    Entry, Label, StringVar, messagebox
)
from tkinter import ttk  # for Combobox

import db_manager  # <-- التعامل مع قاعدة البيانات

OUTPUT_PATH = Path(__file__).parent
ASSETS_PATH = OUTPUT_PATH / "assets" / "frame6"

def relative_to_assets(name: str) -> Path:
    return ASSETS_PATH / name

class Setting(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, bg="#FDF8F9")
        self.controller = controller
        self.email_panel = None
        self.schedule_panel = None
        self.help_panel = None

        self._create_scrollable_canvas()
        self._create_sidebar()
        self._create_top_buttons()

    def _create_scrollable_canvas(self):
        self.main_canvas = Canvas(self, bg="#FDF8F9", highlightthickness=0)
        vsb = Scrollbar(self, orient="vertical", command=self.main_canvas.yview)
        self.scroll_frame = Frame(self.main_canvas, bg="#FDF8F9")
        self.scroll_frame.bind(
            "<Configure>",
            lambda e: self.main_canvas.configure(
                scrollregion=self.main_canvas.bbox("all")
            )
        )
        self.main_canvas.create_window((0, 0), window=self.scroll_frame, anchor="nw")
        self.main_canvas.configure(yscrollcommand=vsb.set)
        self.main_canvas.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")

        self.canvas = Canvas(
            self.scroll_frame,
            bg="#FDF8F9",
            height=900,
            width=1300,
            bd=0,
            highlightthickness=0,
            relief="ridge"
        )
        self.canvas.pack(fill="both", expand=True)
        self.canvas.create_rectangle(0, 0, 328, 900, fill="#45BB80", outline="")

        self.images = []
        def load_image(name: str):
            img = PhotoImage(file=relative_to_assets(name))
            self.images.append(img)
            return img
        self.load_image = load_image

    def _create_sidebar(self):
        nav = [
            ("button_1.png", "Real-Time"),
            ("button_2.png", "Schedule-Scan"),
            ("button_3.png", "Alert-Box"),
            ("button_4.png", "Dashboard"),
            ("button_5.png", "File Details"),
            ("button_6.png", "Setting")
        ]
        for i, (imgf, page) in enumerate(nav):
            btn = Button(
                self.canvas,
                image=self.load_image(imgf),
                bd=0, highlightthickness=0,
                command=lambda p=page: self.controller.show_page(p),
                relief="flat"
            )
            self.canvas.create_window(
                27, 137 + i * 110,
                window=btn, width=274, height=74, anchor="nw"
            )

    def _create_top_buttons(self):
        actions = [
            ("button_10.png", self._show_email_panel),
            ("button_7.png",  self._show_schedule_panel),
            ("button_9.png",  self._show_help_panel)
        ]
        x = 454
        for imgf, cmd in actions:
            btn = Button(
                self.canvas,
                image=self.load_image(imgf),
                bd=0, highlightthickness=0,
                command=cmd,
                relief="raised"
            )
            self.canvas.create_window(x, 147, window=btn, width=156, height=70, anchor="nw")
            x += 180

        # Decorative images
        for fn, coord in [
            ("image_1.png", (1267, 867)),
            ("image_2.png", (819, 41)),
            ("image_3.png", (817, 541))
        ]:
            self.canvas.create_image(coord[0], coord[1], image=self.load_image(fn))

    def _clear_panels(self):
        for panel in (self.email_panel, self.schedule_panel, self.help_panel):
            if panel:
                panel.destroy()
        self.email_panel = self.schedule_panel = self.help_panel = None

    def _show_email_panel(self):
        self._clear_panels()
        panel = Frame(self.canvas, bg="#DFF0D8", bd=2, relief="groove")
        panel.place(x=400, y=260, width=800, height=200)

        Label(panel, text="Alert Receiver Email:", bg="#DFF0D8",
              font=("Arial", 14, "bold")).place(x=20, y=20)
        entry = Entry(panel, width=40, font=("Arial", 12))
        entry.place(x=260, y=22)

        current_email = db_manager.get_user_email()
        if current_email:
            entry.insert(0, current_email)

        # more robust email validation pattern
        pattern = r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$"

        def save_email():
            mail = entry.get().strip()
            if not re.match(pattern, mail):
                messagebox.showerror("Invalid Email", "Please enter a valid email address.")
                return
            db_manager.update_user_email(mail)
            messagebox.showinfo("Saved", f"Alert receiver set to:\n{mail}")

        Button(panel, text="Save Email", font=("Arial", 12),
               command=save_email).place(x=350, y=150)

        self.email_panel = panel

    def _show_schedule_panel(self):
        self._clear_panels()
        panel = Frame(self.canvas, bg="#DFF0D8", bd=2, relief="groove")
        panel.place(x=400, y=260, width=800, height=300)

        # Fetch existing config (stored as minutes, hours, days)
        cfg = db_manager.get_schedule_config()
        h0, m0, l0 = cfg if cfg else (30, 24, 168)

        # High interval
        Label(panel, text="High Interval:", bg="#DFF0D8", font=("Arial", 14)).place(x=20, y=20)
        h_entry = Entry(panel, width=8, font=("Arial", 12))
        h_entry.place(x=160, y=22)
        h_entry.insert(0, h0)
        h_unit = ttk.Combobox(panel, values=["Minutes","Hours","Days"], width=8, state="readonly")
        h_unit.place(x=260, y=22); h_unit.set("Minutes")

        # Medium interval
        Label(panel, text="Medium Interval:", bg="#DFF0D8", font=("Arial", 14)).place(x=20, y=70)
        m_entry = Entry(panel, width=8, font=("Arial", 12))
        m_entry.place(x=160, y=72)
        m_entry.insert(0, m0)
        m_unit = ttk.Combobox(panel, values=["Minutes","Hours","Days"], width=8, state="readonly")
        m_unit.place(x=260, y=72); m_unit.set("Hours")

        # Low interval
        Label(panel, text="Low Interval:", bg="#DFF0D8", font=("Arial", 14)).place(x=20, y=120)
        l_entry = Entry(panel, width=8, font=("Arial", 12))
        l_entry.place(x=160, y=122)
        l_entry.insert(0, l0)
        l_unit = ttk.Combobox(panel, values=["Minutes","Hours","Days"], width=8, state="readonly")
        l_unit.place(x=260, y=122); l_unit.set("Days")

        def save_sched():
            try:
                hv = float(h_entry.get()); mv = float(m_entry.get()); lv = float(l_entry.get())
                # helper to convert any unit to minutes
                def to_minutes(val, unit):
                    if unit=="Minutes": return val
                    if unit=="Hours":   return val*60
                    return val*1440
                h_min = to_minutes(hv, h_unit.get())
                m_min = to_minutes(mv, m_unit.get())
                l_min = to_minutes(lv, l_unit.get())

                if h_min <= 0 or m_min <= 0 or l_min <= 0:
                    raise ValueError("Intervals must be strictly positive.")

                # convert back to storage format
                store_h = int(h_min)
                store_m = int(m_min/60)
                store_l = int(l_min/1440)

                db_manager.update_schedule_config(store_h, store_m, store_l)
                messagebox.showinfo(
                    "Saved",
                    f"Schedule updated:\nHigh={store_h} min, Medium={store_m} hr, Low={store_l} d"
                )
            except ValueError as ve:
                messagebox.showerror("Invalid", str(ve))
            except Exception:
                messagebox.showerror("Invalid", "Ensure numbers are valid and non-zero.")

        Button(panel, text="Save Schedule", font=("Arial", 12),
               command=save_sched).place(x=350, y=200)

        self.schedule_panel = panel

    def _show_help_panel(self):
        self._clear_panels()
        panel = Frame(self.canvas, bg="#DFF0D8", bd=2, relief="groove")
        panel.place(x=400, y=260, width=800, height=500)

        text = tk.Text(panel, wrap="word", bg="#DFF0D8", bd=0)
        sb = Scrollbar(panel, command=text.yview)
        text.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        text.pack(side="left", fill="both", expand=True, padx=10, pady=10)

        help_txt = """
DataGuard Help

1. Overview
DataGuard watches your files for unauthorized changes in real-time or on a schedule. Get instant pop-up alerts and email logs.

2. Getting Started
• Real-Time: Select files → Start to begin live monitoring.
• Schedule Scan: Add files & sensitivity levels (High/Med/Low) → Start Schedule.

3. Alerts & Notifications
• Pop-Up: You’ll see a dialog when a file changes.
• Email: In Settings → Email, enter your address for full-change logs.

4. Dashboard & File Details
• Dashboard: Monitored files count, total alerts, sensitivity chart.
• File Details: Click a file to view hash, size, owner, last modified, permissions, sensitivity.

5. Settings
• Email: Enter your alert-receiver address.
• Schedule Scan: Customize scan intervals (mins/hrs/days).

6. Troubleshooting
• No Emails? Check your Gmail app password and spam folder.
• Python Errors? Install dependencies:
    pip install watchdog cryptography

7. Support
For support, email: data.guard212@gmail.com
"""
        text.insert("1.0", help_txt)
        text.configure(state="disabled")
        self.help_panel = panel
