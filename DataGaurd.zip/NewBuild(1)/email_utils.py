# email_utils.py

from email.message import EmailMessage
import smtplib
import db_manager
from cryptography.fernet import Fernet
from pathlib import Path

# your existing constants…
BASE       = Path(__file__).parent
KEY_FILE   = BASE / 'key.key'
SECRET_FILE= BASE / 'email_secret.bin'
SENDER     = 'data.guard212@gmail.com'

def _get_password() -> str:
    key   = KEY_FILE.read_bytes()
    token = SECRET_FILE.read_bytes()
    return Fernet(key).decrypt(token).decode()

def get_receiver() -> str|None:
    return db_manager.get_user_email()  # ← pull from SQLite

def send_email(subject: str, body: str):
    to = get_receiver()
    if not to:
        # you can comment this out once you know it's configured
        print("No receiver configured")
        return
    app_password = _get_password()
    msg = EmailMessage()
    msg['Subject'] = subject
    msg['From']    = SENDER
    msg['To']      = to
    msg.set_content(body)

    try:
        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as smtp:
            smtp.login(SENDER, app_password)
            smtp.send_message(msg)
    except Exception as e:
        print("Failed to send email:", e)
