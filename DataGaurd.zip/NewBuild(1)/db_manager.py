import sqlite3
from pathlib import Path

DB_FILE = Path(__file__).parent / "dataguard.db"

# =============================================================
# Initialize Database
# =============================================================
def initialize_db():
    with sqlite3.connect(DB_FILE) as conn:
        c = conn.cursor()

        c.execute('''CREATE TABLE IF NOT EXISTS real_time_files (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        path TEXT UNIQUE NOT NULL
                    )''')

        c.execute('''CREATE TABLE IF NOT EXISTS scheduled_files (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        path TEXT UNIQUE NOT NULL,
                        level TEXT
                    )''')

        c.execute('''CREATE TABLE IF NOT EXISTS alert_logs (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        log TEXT NOT NULL
                    )''')

        c.execute('''CREATE TABLE IF NOT EXISTS file_details (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        path TEXT UNIQUE NOT NULL,
                        sha256 TEXT,
                        size TEXT,
                        owner TEXT,
                        last_modified TEXT,
                        permissions TEXT,
                        sensitivity TEXT
                    )''')

        c.execute('''CREATE TABLE IF NOT EXISTS schedule_config (
                        id INTEGER PRIMARY KEY,
                        high INTEGER,
                        medium INTEGER,
                        low INTEGER
                    )''')

        c.execute('''CREATE TABLE IF NOT EXISTS user_settings (
                        id INTEGER PRIMARY KEY,
                        email TEXT
                    )''')

        conn.commit()

# =============================================================
# Real-Time Files
# =============================================================
def insert_real_time_file(path):
    with sqlite3.connect(DB_FILE) as conn:
        conn.execute("INSERT OR IGNORE INTO real_time_files (path) VALUES (?)", (path,))

def delete_real_time_file(path):
    with sqlite3.connect(DB_FILE) as conn:
        conn.execute("DELETE FROM real_time_files WHERE path = ?", (path,))

def get_real_time_files():
    with sqlite3.connect(DB_FILE) as conn:
        cur = conn.execute("SELECT path FROM real_time_files")
        return [row[0] for row in cur.fetchall()]

# =============================================================
# Scheduled Files
# =============================================================
def insert_scheduled_file(path, level):
    with sqlite3.connect(DB_FILE) as conn:
        conn.execute("INSERT OR REPLACE INTO scheduled_files (path, level) VALUES (?, ?)", (path, level))

def delete_scheduled_file(path):
    with sqlite3.connect(DB_FILE) as conn:
        conn.execute("DELETE FROM scheduled_files WHERE path = ?", (path,))

def get_scheduled_files():
    with sqlite3.connect(DB_FILE) as conn:
        cur = conn.execute("SELECT path, level FROM scheduled_files")
        return {row[0]: row[1] for row in cur.fetchall()}

# =============================================================
# Alert Logs
# =============================================================
def insert_alert_log(log):
    with sqlite3.connect(DB_FILE) as conn:
        conn.execute("INSERT INTO alert_logs (log) VALUES (?)", (log,))

def get_alert_logs():
    with sqlite3.connect(DB_FILE) as conn:
        cur = conn.execute("SELECT log FROM alert_logs")
        return [row[0] for row in cur.fetchall()]

def clear_alert_logs():
    """Delete all alert entries from the database."""
    with sqlite3.connect(DB_FILE) as conn:
        conn.execute("DELETE FROM alert_logs")

# =============================================================
# File Details
# =============================================================
def insert_or_update_file_detail(path, sha256, size, owner, last_modified, permissions, sensitivity):
    with sqlite3.connect(DB_FILE) as conn:
        conn.execute('''INSERT OR REPLACE INTO file_details
                        (path, sha256, size, owner, last_modified, permissions, sensitivity)
                        VALUES (?, ?, ?, ?, ?, ?, ?)''',
                     (path, sha256, size, owner, last_modified, permissions, sensitivity))

def get_file_details(path):
    with sqlite3.connect(DB_FILE) as conn:
        cur = conn.execute("SELECT * FROM file_details WHERE path = ?", (path,))
        return cur.fetchone()

# =============================================================
# Schedule Config
# =============================================================
def update_schedule_config(high, medium, low):
    with sqlite3.connect(DB_FILE) as conn:
        conn.execute("INSERT OR REPLACE INTO schedule_config (id, high, medium, low) VALUES (1, ?, ?, ?)", (high, medium, low))

def get_schedule_config():
    with sqlite3.connect(DB_FILE) as conn:
        cur = conn.execute("SELECT high, medium, low FROM schedule_config WHERE id = 1")
        return cur.fetchone()

# =============================================================
# User Settings
# =============================================================
def update_user_email(email):
    with sqlite3.connect(DB_FILE) as conn:
        conn.execute("INSERT OR REPLACE INTO user_settings (id, email) VALUES (1, ?)", (email,))

def get_user_email():
    with sqlite3.connect(DB_FILE) as conn:
        cur = conn.execute("SELECT email FROM user_settings WHERE id = 1")
        row = cur.fetchone()
        return row[0] if row else None

# =============================================================
# Auto Initialize when imported
# =============================================================
initialize_db()
