import tkinter as tk

from Start import StartPage
from Real_Time import Real_Time
from Schedule_Scan import ScheduleScan
from Alert_Box import AlertBox
from Dashboard import Dashboard
from File_Details import FileDetails
from Setting import Setting

import db_manager  # <-- Initialize Database

# =============================================================
# Initialize Database
# =============================================================
db_manager.initialize_db()

# =============================================================
# Main Application Class
# =============================================================
class AppController(tk.Tk):
    def __init__(self):
        super().__init__()

        self.title("DataGuard - File Integrity Monitoring")
        self.geometry("1300x900")  # Adjust this if needed for your layout
        self.resizable(True, True)  # This ensures the window is resizable

        # Shared State
        self.selected_files = []
        self.alert_logs = []

        self.container = tk.Frame(self)
        self.container.pack(fill="both", expand=True)

        self.pages = {
            "Start": StartPage,
            "Real-Time": Real_Time,
            "Schedule-Scan": ScheduleScan,
            "Alert-Box": AlertBox,
            "Dashboard": Dashboard,
            "File Details": FileDetails,
            "Setting": Setting,
        }

        self.show_page("Start")

    def show_page(self, page_name):
        # Destroy existing page (if any)
        for widget in self.container.winfo_children():
            widget.destroy()

        # Instantiate and pack the new page
        page_cls = self.pages[page_name]
        page = page_cls(self.container, self)
        page.pack(fill="both", expand=True)

        # Special handling for Alert-Box page
        if page_name == "Alert-Box" and hasattr(page, "load_alerts"):
            page.load_alerts()

# =============================================================
# Run the Application
# =============================================================
if __name__ == "__main__":
    app = AppController()
    app.mainloop()
