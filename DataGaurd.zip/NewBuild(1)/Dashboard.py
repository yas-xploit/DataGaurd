from pathlib import Path
import tkinter as tk
from tkinter import Canvas, Button, PhotoImage, Scrollbar, ttk
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.ticker import MaxNLocator

import db_manager  # <-- التعامل مع قاعدة البيانات

OUTPUT_PATH = Path(__file__).parent
ASSETS_PATH   = OUTPUT_PATH / "assets" / "frame4"

def relative_to_assets(name: str) -> Path:
    return ASSETS_PATH / name

class Dashboard(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, bg="#FDF8F9")
        self.controller = controller

        # make it scrollable if needed
        self.canvas = Canvas(self, bg="#FDF8F9", bd=0, highlightthickness=0)
        vbar = Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=vbar.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        vbar.pack(side="right", fill="y")

        self.images = []
        def load_image(fn):
            img = PhotoImage(file=relative_to_assets(fn))
            self.images.append(img)
            return img

        # Sidebar
        self.canvas.create_rectangle(0, 0, 328, 900, fill="#45BB80", outline="")
        nav = [
            ("button_1.png", "Real-Time"), ("button_2.png", "Schedule-Scan"),
            ("button_3.png", "Alert-Box"),   ("button_4.png", "Dashboard"),
            ("button_5.png", "File Details"),("button_6.png", "Setting")
        ]
        for i, (imgf, page) in enumerate(nav):
            btn = Button(
                self.canvas,
                image=load_image(imgf),
                bd=0,
                highlightthickness=0,
                command=lambda p=page: controller.show_page(p),
                relief="flat"
            )
            self.canvas.create_window(27, 137 + i*110, window=btn, width=274, height=74, anchor="nw")

        # Decorations
        self.canvas.create_image(810, 41,  image=load_image("image_2.png"))
        self.canvas.create_image(1045,130, image=load_image("image_1.png"))
        self.canvas.create_image(811, 467, image=load_image("image_3.png"))
        self.canvas.create_image(1267,867, image=load_image("image_4.png"))

        # Treeview: File Path | Alert Count
        self.tree = ttk.Treeview(
            self.canvas,
            columns=("File Path","Alert Count"),
            show="headings",
            height=20
        )
        self.tree.heading("File Path", text="File Path")
        self.tree.heading("Alert Count", text="Alert Count")
        self.tree.column("File Path", width=400)
        self.tree.column("Alert Count", width=120)
        self.canvas.create_window(370, 166, window=self.tree, anchor="nw")

        # Stats labels
        self.stats_frame = tk.Frame(self.canvas, bg="#FDF8F9")
        self.canvas.create_window(900,166, window=self.stats_frame, anchor="nw")
        self.file_count_label  = tk.Label(
            self.stats_frame, text="Monitored Files: 0",
            bg="#FDF8F9", font=("Arial",14)
        )
        self.alert_count_label = tk.Label(
            self.stats_frame, text="Total Alerts: 0",
            bg="#FDF8F9", font=("Arial",14)
        )
        self.sensitivity_label = tk.Label(
            self.stats_frame,
            text="Sensitivity Levels: High=0, Medium=0, Low=0",
            bg="#FDF8F9", font=("Arial",14)
        )
        for lbl in (self.file_count_label, self.alert_count_label, self.sensitivity_label):
            lbl.pack(anchor="w")

        # Chart
        self._init_chart()

        # Refresh whenever this frame is shown
        self.bind("<Map>", lambda e: self.update_stats())

        # Initial load
        self.update_stats()

    def _init_chart(self):
        self.fig, self.ax = plt.subplots(figsize=(3.5,2.5))
        self.chart = FigureCanvasTkAgg(self.fig, self.canvas)
        self.chart.get_tk_widget().place(x=910, y=380)

    def update_stats(self):
        # load DB data
        rt = db_manager.get_real_time_files()
        sc = db_manager.get_scheduled_files()
        al = db_manager.get_alert_logs()

        # update stats labels
        all_files = list(dict.fromkeys(rt + list(sc.keys())))
        self.file_count_label.config(text=f"Monitored Files: {len(all_files)}")
        self.alert_count_label.config(text=f"Total Alerts: {len(al)}")

        # rebuild tree with correct per-file counts
        counts = {}
        for log in al:
            first = log.split("\n", 1)[0]
            if first.startswith("[ALERT]"):
                # real-time
                fp = first.split("File Changed:")[-1].strip()
            elif first.startswith("[SCHEDULE ALERT]"):
                # scheduled
                fp = first.split("File:")[-1].split("(")[0].strip()
            else:
                continue
            counts[fp] = counts.get(fp, 0) + 1

        # clear and reinsert
        for item in self.tree.get_children():
            self.tree.delete(item)
        for p in all_files:
            self.tree.insert("", "end", values=(p, counts.get(p, 0)))

        # sensitivity breakdown
        from collections import Counter
        lvl_counts = Counter(sc.values())
        self.sensitivity_label.config(
            text=f"Sensitivity Levels: High={lvl_counts.get('High',0)}, "
                 f"Medium={lvl_counts.get('Medium',0)}, Low={lvl_counts.get('Low',0)}"
        )

        # redraw chart
        self.ax.clear()
        labels = ["High","Medium","Low"]
        vals   = [lvl_counts.get(l,0) for l in labels]
        self.ax.bar(labels, vals)
        self.ax.set_ylabel("File Count")
        self.ax.set_title("File Sensitivity Levels")
        self.ax.yaxis.set_major_locator(MaxNLocator(integer=True))
        self.ax.set_ylim(0, 10)
        self.fig.tight_layout()
        self.chart.draw()
