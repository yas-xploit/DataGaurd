from pathlib import Path
import tkinter as tk
from tkinter import Canvas, Button, PhotoImage, Frame, Scrollbar, Listbox

# ── Human-readable size helper ─────────────────────────────────────────
def human_readable_size(num_bytes):
    num = float(num_bytes)
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if num < 1024 or unit == "TB":
            return f"{num:.2f} {unit}"
        num /= 1024

import db_manager  # <-- التعامل مع قاعدة البيانات

OUTPUT_PATH = Path(__file__).parent
ASSETS_PATH = OUTPUT_PATH / "assets" / "frame5"

def relative_to_assets(name: str) -> Path:
    return ASSETS_PATH / name

class FileDetails(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, bg="#FDF8F9")
        self.controller = controller

        # scrollable canvas
        main_canvas = Canvas(self, bg="#FDF8F9", highlightthickness=0)
        scrollbar = Scrollbar(self, orient="vertical", command=main_canvas.yview)
        scroll_frame = Frame(main_canvas, bg="#FDF8F9")
        scroll_frame.bind(
            "<Configure>",
            lambda e: main_canvas.configure(scrollregion=main_canvas.bbox("all"))
        )
        main_canvas.create_window((0, 0), window=scroll_frame, anchor="nw")
        main_canvas.configure(yscrollcommand=scrollbar.set)

        main_canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        canvas = Canvas(
            scroll_frame,
            bg="#FDF8F9",
            width=1300,
            height=900,
            bd=0,
            highlightthickness=0,
            relief="ridge"
        )
        canvas.pack(fill="both", expand=True)

        # sidebar background
        canvas.create_rectangle(0, 0, 328, 900, fill="#45BB80", outline="")

        # navigation buttons
        self.images = []
        def load_img(fn):
            img = PhotoImage(file=relative_to_assets(fn))
            self.images.append(img)
            return img

        def nav_btn(fn, x, y, w, h, page):
            img = load_img(fn)
            btn = Button(scroll_frame, image=img, bd=0, highlightthickness=0,
                         command=lambda: controller.show_page(page), relief="flat")
            btn.place(x=x, y=y, width=w, height=h)

        nav_btn("button_1.png", 27, 137, 274, 74, "Real-Time")
        nav_btn("button_2.png", 27, 247, 274, 74, "Schedule-Scan")
        nav_btn("button_3.png", 27, 357, 274, 74, "Alert-Box")
        nav_btn("button_4.png", 27, 467, 274, 74, "Dashboard")
        nav_btn("button_5.png", 27, 577, 274, 74, "File Details")
        nav_btn("button_6.png", 26, 687, 275, 75, "Setting")

        # decorative images
        canvas.create_image(1267, 40,  image=load_img("image_1.png"))
        canvas.create_image(819,  41,  image=load_img("image_2.png"))
        canvas.create_image(811, 467, image=load_img("image_3.png"))
        canvas.create_image(1046,393, image=load_img("image_4.png"))
        canvas.create_image(573, 393, image=load_img("image_5.png"))

        # Titles and listboxes
        canvas.create_text(490, 144, anchor="nw",
                           text="Monitored Files", font=("Arial", 16, "bold"))
        self.monitored_listbox = Listbox(canvas, height=29, width=60)
        canvas.create_window(390, 166, window=self.monitored_listbox, anchor="nw")

        canvas.create_text(985, 144, anchor="nw",
                           text="File Metadata", font=("Arial", 16, "bold"))
        self.metadata_listbox = Listbox(canvas, height=29, width=60)
        canvas.create_window(865, 166, window=self.metadata_listbox, anchor="nw")

        # Populate and bind
        self.populate_files()
        self.monitored_listbox.bind("<<ListboxSelect>>", self.on_select)

    def populate_files(self):
        inserted = set()
        real_time_files = db_manager.get_real_time_files()
        scheduled_files = db_manager.get_scheduled_files()

        for p in real_time_files + list(scheduled_files.keys()):
            if p not in inserted:
                self.monitored_listbox.insert("end", p)
                inserted.add(p)

    def on_select(self, _evt):
        sel = self.monitored_listbox.curselection()
        if not sel:
            return
        path = self.monitored_listbox.get(sel[0])

        self.metadata_listbox.delete(0, "end")

        details = db_manager.get_file_details(path)
        if details:
            _, path, sha256, size, owner, last_modified, permissions, sensitivity = details

            # convert size to human‐readable
            try:
                hr_size = human_readable_size(int(size))
            except Exception:
                hr_size = f"{size} B"

            lines = [
                f"File Name: {Path(path).name}",
                f"Full Path: {path}",
                f"SHA-256: {sha256}",
                f"Size: {hr_size}",
                f"Owner UID: {owner}",
                f"Last Modified: {last_modified}",
                f"Permissions: {permissions}",
                f"Sensitivity: {sensitivity}"
            ]
            for line in lines:
                self.metadata_listbox.insert("end", line)
        else:
            self.metadata_listbox.insert("end", "No metadata available.")
