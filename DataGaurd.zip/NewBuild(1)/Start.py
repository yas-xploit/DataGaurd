from pathlib import Path
import tkinter as tk
from tkinter import Canvas, Button, PhotoImage, Frame, Scrollbar

OUTPUT_PATH = Path(__file__).parent
ASSETS_PATH = OUTPUT_PATH / "assets" / "frame0"

def relative_to_assets(path: str) -> Path:
    return ASSETS_PATH / Path(path)

class StartPage(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.configure(bg="#FDF8F9")

        main_canvas = Canvas(self, bg="#FDF8F9", highlightthickness=0)
        scrollbar = Scrollbar(self, orient="vertical", command=main_canvas.yview)
        scrollable_frame = Frame(main_canvas, bg="#FDF8F9")

        scrollable_frame.bind(
            "<Configure>",
            lambda e: main_canvas.configure(scrollregion=main_canvas.bbox("all"))
        )

        main_canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        main_canvas.configure(yscrollcommand=scrollbar.set)

        main_canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        canvas = Canvas(
            scrollable_frame,
            bg="#FDF8F9",
            height=900,
            width=1300,
            bd=0,
            highlightthickness=0,
            relief="ridge"
        )
        canvas.pack(fill="both", expand=True)

        canvas.create_rectangle(0.0, 0.0, 423.0, 900.0, fill="#45BB80", outline="")

        self.images = []

        def load_image(name):
            img = PhotoImage(file=relative_to_assets(name))
            self.images.append(img)
            return img

        # Static Images
        image_1 = load_image("image_1.png")
        canvas.create_image(212.0, 387.0, image=image_1)

        image_2 = load_image("image_2.png")
        canvas.create_image(848.0, 165.0, image=image_2)

        image_3 = load_image("image_3.png")
        canvas.create_image(1236.0, 836.0, image=image_3)

        image_4 = load_image("image_4.png")
        canvas.create_image(197.0, 669.0, image=image_4)

        button_img = load_image("button_1.png")
        button = Button(
            scrollable_frame,
            image=button_img,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: controller.show_page("Real-Time"),
            relief="flat"
        )
        button.place(x=688.0, y=402.0, width=319.0, height=96.0)
