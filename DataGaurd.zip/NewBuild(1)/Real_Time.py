# Real_Time.py

from pathlib import Path
import tkinter as tk
from tkinter import Canvas, Button, PhotoImage, Scrollbar, messagebox, filedialog
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from difflib import SequenceMatcher
import os
import hashlib
import time

import db_manager     # ← handles insert_or_update_file_detail, insert_alert_log, etc.
from email_utils import send_email

OUTPUT_PATH = Path(__file__).parent
ASSETS_PATH   = OUTPUT_PATH / "assets" / "frame1"

# only these extensions will be monitored
ALLOWED_EXT = {
    ".sh", ".py", ".ps1", ".pl",
    ".dll", ".jar",
    ".xlsx", ".docx", ".pdf",
    ".xml", ".csv", ".htm", ".log", ".js", ".txt"
}

def relative_to_assets(fn: str) -> Path:
    return ASSETS_PATH / fn

class Real_Time(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, bg="#FDF8F9")
        self.controller = controller
        self.monitors   = []   # holds Observer instances
        self._running   = False

        # ── scrollable canvas ──────────────────────────────────────────
        self.canvas = Canvas(self, bg="#FDF8F9", bd=0, highlightthickness=0)
        vbar = Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=vbar.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        vbar.pack(side="right", fill="y")
        self.canvas.bind(
            "<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        )
        self.canvas.create_rectangle(0, 0, 328, 900, fill="#45BB80", outline="")

        # ── image loader ───────────────────────────────────────────────
        self.images = []
        def load_image(fn):
            img = PhotoImage(file=relative_to_assets(fn))
            self.images.append(img)
            return img

        # ── sidebar nav ──────────────────────────────────────────────
        def place_btn(fn, x, y, w, h, cmd=None):
            img = load_image(fn)
            btn = Button(
                self.canvas, image=img,
                bd=0, highlightthickness=0,
                command=cmd or (lambda: None),
                relief="flat"
            )
            self.canvas.create_window(x, y, window=btn,
                                      width=w, height=h, anchor="nw")

        place_btn("button_1.png", 27, 137, 274, 74)
        place_btn("button_2.png", 27, 247, 274, 74,
                  lambda: controller.show_page("Schedule-Scan"))
        place_btn("button_3.png", 27, 357, 274, 74,
                  lambda: controller.show_page("Alert-Box"))
        place_btn("button_4.png", 27, 467, 274, 74,
                  lambda: controller.show_page("Dashboard"))
        place_btn("button_5.png", 27, 577, 274, 74,
                  lambda: controller.show_page("File Details"))
        place_btn("button_6.png", 26, 687, 275, 75,
                  lambda: controller.show_page("Setting"))

        # ── decorations ───────────────────────────────────────────────
        for fn, x, y in [
            ("image_9.png", 811, 467), ("image_1.png", 1267, 867),
            ("image_2.png", 1046, 393), ("image_3.png", 1045, 130),
            ("image_4.png", 573, 393),  ("image_5.png", 571, 396),
            ("image_6.png", 1045, 396), ("image_7.png", 572, 130),
            ("image_8.png", 810, 41),
        ]:
            self.canvas.create_image(x, y, image=load_image(fn))

        # ── file lists ───────────────────────────────────────────────
        self.default_listbox  = tk.Listbox(self.canvas, height=29, width=60)
        self.selected_listbox = tk.Listbox(self.canvas, height=29, width=60)
        self.canvas.create_window(865, 166, window=self.default_listbox,  anchor="nw")
        self.canvas.create_window(390, 166, window=self.selected_listbox, anchor="nw")

        # insert a sensible default (hosts) if you like—no extension check here
        defaults = [r"C:\Windows\System32\drivers\etc\hosts"]
        for f in defaults:
            self.default_listbox.insert("end", f)
            db_manager.insert_real_time_file(f)
            self._insert_metadata(f)

        # load previously saved files
        for f in db_manager.get_real_time_files():
            self.selected_listbox.insert("end", f)
            self._insert_metadata(f)

        # ── action buttons ───────────────────────────────────────────
        place_btn("button_7.png", 390, 650, 140, 59, self.start_monitoring)
        place_btn("button_8.png", 546, 650, 140, 59, self.stop_monitoring)
        place_btn("button_9.png", 420, 751, 140, 59, self.select_file)
        place_btn("button_10.png", 580, 751, 140, 59, self.delete_selected_file)
        place_btn("button_11.png", 740, 751, 140, 59, self.clear_all_files)

    def _calculate_sha256(self, path):
        sha256 = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                sha256.update(chunk)
        return sha256.hexdigest()

    def _insert_metadata(self, path):
        """Capture initial metadata so we can diff later."""
        try:
            sha = self._calculate_sha256(path)
            st  = os.stat(path)
            db_manager.insert_or_update_file_detail(
                path,
                sha,
                st.st_size,
                st.st_uid,
                time.ctime(st.st_mtime),
                oct(st.st_mode)[-3:],
                "Real-Time"
            )
        except Exception as e:
            print(f"[Metadata Error] {path}: {e}")

    def select_file(self):
        files = filedialog.askopenfilenames(
            title="Select files to monitor",
            filetypes=[("All files","*.*")]
        )
        for p in files:
            ext = Path(p).suffix.lower()
            if ext not in ALLOWED_EXT:
                messagebox.showwarning(
                    "Skipped",
                    f"{Path(p).name} has extension {ext!r} which is not allowed."
                )
                continue
            db_manager.insert_real_time_file(p)
            self.selected_listbox.insert("end", p)
            self._insert_metadata(p)

    def delete_selected_file(self):
        sel = self.selected_listbox.curselection()
        if not sel:
            messagebox.showinfo("Delete File", "Please select a file.")
            return
        path = self.selected_listbox.get(sel[0])
        self.selected_listbox.delete(sel[0])
        db_manager.delete_real_time_file(path)

    def clear_all_files(self):
        if messagebox.askyesno("Clear All", "Remove all files?"):
            for p in db_manager.get_real_time_files():
                db_manager.delete_real_time_file(p)
            self.selected_listbox.delete(0, "end")

    def start_monitoring(self):
        if self._running:
            messagebox.showinfo("Monitoring", "Already running.")
            return

        paths = db_manager.get_real_time_files()
        if not paths:
            messagebox.showwarning("Empty", "No files selected.")
            return

        # stop any old observers
        self.stop_monitoring()

        self._running = True
        for file_path in paths:
            obs = Observer()
            handler = self._FileChangeHandler(file_path, self)
            obs.schedule(handler, path=os.path.dirname(file_path), recursive=False)
            obs.daemon = True
            obs.start()
            self.monitors.append(obs)

        messagebox.showinfo("Monitoring", "Started.")

    def stop_monitoring(self):
        if not self._running:
            return
        self._running = False
        for obs in self.monitors:
            obs.stop()
            obs.join()
        self.monitors.clear()
        messagebox.showinfo("Monitoring", "Stopped.")

    class _FileChangeHandler(FileSystemEventHandler):
        def __init__(self, file_path, parent):
            self.file_path = file_path
            self.parent    = parent

            row = db_manager.get_file_details(file_path)
            if row:
                # unpack the saved fields
                _, _, self.last_hash, self.last_size, self.last_owner, \
                self.last_mtime, self.last_perms, _ = row
                # also seed previous content
                try:
                    with open(file_path, "rb") as f:
                        self.last_content = f.read()
                except:
                    self.last_content = b""
            else:
                # fallback seeds
                self.last_hash    = parent._calculate_sha256(file_path)
                st = os.stat(file_path)
                self.last_size    = st.st_size
                self.last_owner   = st.st_uid
                self.last_mtime   = time.ctime(st.st_mtime)
                self.last_perms   = oct(st.st_mode)[-3:]
                try:
                    with open(file_path, "rb") as f:
                        self.last_content = f.read()
                except:
                    self.last_content = b""

        def on_modified(self, event):
            if not self.parent._running:
                return
            if os.path.abspath(event.src_path) != os.path.abspath(self.file_path):
                return

            # read new content
            try:
                with open(self.file_path, "rb") as f:
                    new_content = f.read()
            except:
                new_content = b""
            new_hash = hashlib.sha256(new_content).hexdigest()
            st       = os.stat(self.file_path)
            new_size  = st.st_size
            new_owner = st.st_uid
            new_mtime = time.ctime(st.st_mtime)
            new_perms = oct(st.st_mode)[-3:]

            # collect any diffs
            diffs = []
            if new_hash   != self.last_hash:
                diffs.append(("Hash",         self.last_hash,    new_hash))
            if new_size   != self.last_size:
                diffs.append(("Size",         str(self.last_size), str(new_size)))
            if new_owner  != self.last_owner:
                diffs.append(("Owner UID",    str(self.last_owner), str(new_owner)))
            if new_mtime  != self.last_mtime:
                diffs.append(("Last Modified", self.last_mtime,    new_mtime))
            if new_perms  != self.last_perms:
                diffs.append(("Permissions",  self.last_perms,    new_perms))

            if not diffs:
                return

            # compute similarity index (%)
            sim = SequenceMatcher(None, self.last_content, new_content).ratio() * 100

            # build detailed log
            log = f"[ALERT] File Changed: {self.file_path}\n"
            for field, old, new in diffs:
                log += f"Old {field}: {old}\nNew {field}: {new}\n"
            log += f"Similarity Index: {sim:.2f}%\n"

            # store + UI + email
            self.parent.controller.alert_logs.append(log)
            db_manager.insert_alert_log(log)
            messagebox.showwarning(
                "Tamper Alert",
                f"Changes in {Path(self.file_path).name}"
            )
            send_email(
                f"Tampering Detected: {Path(self.file_path).name}",
                log
            )

            # update baseline
            db_manager.insert_or_update_file_detail(
                self.file_path,
                new_hash, new_size, new_owner,
                new_mtime, new_perms,
                "Real-Time"
            )
            self.last_hash    = new_hash
            self.last_size    = new_size
            self.last_owner   = new_owner
            self.last_mtime   = new_mtime
            self.last_perms   = new_perms
            self.last_content = new_content
