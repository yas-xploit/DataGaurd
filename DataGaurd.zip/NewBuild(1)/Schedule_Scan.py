# Schedule_Scan.py

from pathlib import Path
import tkinter as tk
from tkinter import (
    Canvas, Button, PhotoImage, Listbox,
    filedialog, messagebox, Toplevel,
    Label, Radiobutton, StringVar
)
import threading
import os
import hashlib
import time

import db_manager
from email_utils import send_email

OUTPUT_PATH = Path(__file__).parent
ASSETS_PATH   = OUTPUT_PATH / "assets" / "frame2"

# Only these extensions are allowed
ALLOWED_EXT = {
    ".sh", ".py", ".ps1", ".pl",
    ".dll", ".jar",
    ".xlsx", ".docx", ".pdf",
    ".xml", ".csv", ".htm", ".log", ".js", ".txt"
}

def relative_to_assets(fn: str) -> Path:
    return ASSETS_PATH / fn

class ScheduleScan(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, bg="#FDF8F9")
        self.controller  = controller
        self.scheduled   = {}      # path → sensitivity
        self.intervals   = self._load_intervals()   # sensitivity → seconds
        self._running    = False
        self._timers     = {}      # path → Timer

        self._load_scheduled()
        self._build_ui()

    def _build_ui(self):
        self.canvas = Canvas(self, bg="#FDF8F9", bd=0, highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)
        self._imgs = []

        def img(fn):
            i = PhotoImage(file=relative_to_assets(fn))
            self._imgs.append(i)
            return i

        # Sidebar
        self.canvas.create_rectangle(0,0,328,900,fill="#45BB80",outline="")
        nav = [
            ("button_1.png","Real-Time"),("button_2.png","Schedule-Scan"),
            ("button_3.png","Alert-Box"),  ("button_4.png","Dashboard"),
            ("button_5.png","File Details"),("button_6.png","Setting")
        ]
        for i,(f,page) in enumerate(nav):
            btn = Button(self.canvas, image=img(f), bd=0, highlightthickness=0,
                         command=lambda p=page: self.controller.show_page(p))
            self.canvas.create_window(27,137+i*110,window=btn,width=274,height=74,anchor="nw")

        # Title + Listbox
        Label(self.canvas, text="Scheduled Files", bg="#FDF8F9",
              font=("Arial",14,"bold")).place(x=400,y=120)
        self.listbox = Listbox(self.canvas, height=23, width=137)
        self.canvas.create_window(400,160,window=self.listbox,anchor="nw")
        for path,lvl in self.scheduled.items():
            self.listbox.insert("end", f"{Path(path).name} → {lvl}")

        # Action buttons
        actions = [
            ("button_9.png",  self._add_files),
            ("button_7.png",  self._start_schedule),
            ("button_8.png",  self._stop_schedule),
            ("button_10.png", self._remove_file),
            ("button_11.png", self._clear_all)
        ]
        for i,(f,cmd) in enumerate(actions):
            b = Button(self.canvas, image=img(f), bd=0, highlightthickness=0, command=cmd)
            self.canvas.create_window(400+i*160,600,window=b,width=140,height=59,anchor="nw")

        # Decorations
        for fn,coord in [
            ("image_9.png",(811,467)),("image_1.png",(1267,867)),
            ("image_2.png",(810,41)),("image_3.png",(814,344)),
            ("image_4.png",(814,346)),("image_5.png",(814,136))
        ]:
            self.canvas.create_image(coord[0], coord[1], image=img(fn))

    def _load_scheduled(self):
        self.scheduled = db_manager.get_scheduled_files()

    def _load_intervals(self):
        cfg = db_manager.get_schedule_config()
        if cfg:
            h, m, l = cfg
            return {
                "High":   h * 60,
                "Medium": m * 3600,
                "Low":    l * 86400
            }
        # defaults
        return {
            "High":   30 * 60,
            "Medium": 24 * 3600,
            "Low":    7 * 86400
        }

    def _ask_sensitivity(self):
        win = Toplevel(self); win.title("Sensitivity")
        var = StringVar(value="Medium")
        Label(win, text="Select sensitivity:").pack(pady=5)
        for lvl in ("High","Medium","Low"):
            Radiobutton(win, text=lvl, variable=var, value=lvl).pack(anchor="w")
        Button(win, text="OK", command=win.destroy).pack(pady=8)
        win.grab_set()
        self.wait_window(win)
        return var.get()

    def _insert_metadata(self, path, lvl):
        try:
            sha = self._calculate_sha256(path)
            st  = os.stat(path)
            db_manager.insert_or_update_file_detail(
                path, sha, st.st_size, st.st_uid,
                time.ctime(st.st_mtime), oct(st.st_mode)[-3:], lvl
            )
        except Exception as e:
            print(f"[Metadata Error] {path}: {e}")

    def _add_files(self):
        files = filedialog.askopenfilenames(
            title="Select files",
            filetypes=[("Allowed", "*"+";*".join(ALLOWED_EXT)), ("All Files","*.*")]
        )
        for p in files:
            ext = Path(p).suffix.lower()
            if ext not in ALLOWED_EXT:
                messagebox.showwarning(
                    "Skipped",
                    f"{Path(p).name} has extension '{ext}', not allowed."
                )
                continue

            if p in self.scheduled:
                continue

            lvl = self._ask_sensitivity()
            db_manager.insert_scheduled_file(p, lvl)
            self.scheduled[p] = lvl
            self.listbox.insert("end", f"{Path(p).name} → {lvl}")
            self._insert_metadata(p, lvl)

    def _remove_file(self):
        sel = self.listbox.curselection()
        if not sel:
            messagebox.showwarning("Delete File", "No file selected.")
            return
        for i in reversed(sel):
            name = self.listbox.get(i).split("→")[0].strip()
            for p in list(self.scheduled):
                if Path(p).name == name:
                    db_manager.delete_scheduled_file(p)
                    del self.scheduled[p]
                    break
            self.listbox.delete(i)

    def _clear_all(self):
        if messagebox.askyesno("Clear","Remove all?"):
            for p in list(self.scheduled):
                db_manager.delete_scheduled_file(p)
                del self.scheduled[p]
            self.listbox.delete(0, "end")

    def _start_schedule(self):
        if self._running:
            messagebox.showinfo("Running","Already scheduled.")
            return
        if not self.scheduled:
            messagebox.showwarning("Empty","No files.")
            return

        self._running = True
        messagebox.showinfo("Started","Each file will run on its own interval.")
        for path,lvl in self.scheduled.items():
            self._schedule_file(path, lvl)

    def _stop_schedule(self):
        self._running = False
        for t in self._timers.values():
            t.cancel()
        self._timers.clear()
        messagebox.showinfo("Stopped","Scheduled monitoring stopped.")

    def _schedule_file(self, path, lvl):
        if not self._running:
            return
        sec = self.intervals[lvl]
        t = threading.Timer(sec, self._run_check, args=(path,lvl))
        t.daemon = True
        t.start()
        self._timers[path] = t

    def _run_check(self, path, lvl):
        if not self._running:
            return

        # old metadata
        row       = db_manager.get_file_details(path) or ()
        old_hash  = row[2] if len(row)>2 else None
        old_size  = row[3] if len(row)>3 else None
        old_lm    = row[5] if len(row)>5 else None
        old_perms = row[6] if len(row)>6 else None

        # new metadata
        new_hash  = self._calculate_sha256(path)
        st        = os.stat(path)
        new_size  = st.st_size
        new_lm    = time.ctime(st.st_mtime)
        new_perms = oct(st.st_mode)[-3:]

        if new_hash != old_hash:
            log = (
                f"[SCHEDULE ALERT] File: {path} ({lvl}) changed.\n"
                f"Old Hash: {old_hash}\nNew Hash: {new_hash}\n"
                f"Old Size: {old_size}\nNew Size: {new_size}\n"
                f"Old Last Modified: {old_lm}\nNew Last Modified: {new_lm}\n"
                f"Old Permissions: {old_perms}\nNew Permissions: {new_perms}\n"
            )
            db_manager.insert_alert_log(log)
            self.controller.alert_logs.append(log)
            messagebox.showwarning("Scheduled Tamper", f"Changes in {Path(path).name}")
            send_email(f"[Scheduled] {Path(path).name} tampered", log)

            # update baseline
            db_manager.insert_or_update_file_detail(
                path, new_hash, new_size, st.st_uid,
                new_lm, new_perms, lvl
            )

        # re‐schedule this file
        self._schedule_file(path, lvl)

    def _calculate_sha256(self, path: str) -> str:
        sha = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                sha.update(chunk)
        return sha.hexdigest()
