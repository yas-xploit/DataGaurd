from pathlib import Path
import re
import tkinter as tk
from tkinter import (
    Canvas, Button, PhotoImage, Frame, Scrollbar,
    Listbox, Text, Label, END, messagebox
)
import os

import db_manager  # <-- التعامل مع قاعدة البيانات

OUTPUT_PATH = Path(__file__).parent
ASSETS_PATH  = OUTPUT_PATH / "assets" / "frame3"

def relative_to_assets(name: str) -> Path:
    return ASSETS_PATH / name

# ── Human-readable size helper ───────────────────────────────────────────
def human_readable_size(num_bytes):
    num = float(num_bytes)
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if num < 1024 or unit == "TB":
            return f"{num:.2f} {unit}"
        num /= 1024

class AlertBox(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, bg="#FDF8F9")
        self.controller = controller

        # ── Canvas & Sidebar ──────────────────────────────────────────────
        self.canvas = Canvas(self, bg="#FDF8F9", highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)
        self.images = []
        def load_image(fn):
            img = PhotoImage(file=relative_to_assets(fn))
            self.images.append(img)
            return img
        def place_button(img_name, x, y, w, h, action=None):
            btn = Button(self.canvas, image=load_image(img_name),
                         borderwidth=0, highlightthickness=0,
                         command=action or (lambda: None), relief="flat")
            self.canvas.create_window(x, y, anchor="nw",
                                      window=btn, width=w, height=h)

        # sidebar background
        self.canvas.create_rectangle(0, 0, 328, 900, fill="#45BB80", outline="")

        # navigation buttons
        nav = [
            ("button_1.png", "Real-Time"),
            ("button_2.png", "Schedule-Scan"),
            ("button_3.png", "Alert-Box"),
            ("button_4.png", "Dashboard"),
            ("button_5.png", "File Details"),
            ("button_6.png", "Setting"),
        ]
        for i, (imgf, page) in enumerate(nav):
            place_button(imgf, 27, 137 + i*110, 274, 74,
                         lambda p=page: controller.show_page(p))

        # ── Alerts List ───────────────────────────────────────────────────
        Label(self.canvas, text="Alerts", bg="#FDF8F9",
              font=("Arial", 14, "bold")
        ).place(x=400, y=160)

        alert_frame = Frame(self.canvas)
        self.alert_listbox = Listbox(alert_frame, width=100, height=10)
        alert_scroll = Scrollbar(alert_frame, orient="vertical",
                                 command=self.alert_listbox.yview)
        self.alert_listbox.config(yscrollcommand=alert_scroll.set)
        self.alert_listbox.pack(side="left", fill="both", expand=True)
        alert_scroll.pack(side="right", fill="y")
        self.canvas.create_window(400, 200,
                                  anchor="nw", window=alert_frame)

        clear_btn = Button(self.canvas, text="Clear Alerts",
                           bg="#FF6666", fg="white", font=("Arial", 12),
                           command=self._clear_alerts)
        self.canvas.create_window(1150, 200,
                                  anchor="nw",
                                  window=clear_btn,
                                  width=120, height=30)

        # ── Alert Details ────────────────────────────────────────────────
        Label(self.canvas, text="Alert Details", bg="#FDF8F9",
              font=("Arial", 14, "bold")
        ).place(x=400, y=380)

        detail_frame = Frame(self.canvas)
        self.detail_box = Text(detail_frame, width=100, height=15, wrap="word")
        detail_scroll = Scrollbar(detail_frame, orient="vertical",
                                  command=self.detail_box.yview)
        self.detail_box.config(yscrollcommand=detail_scroll.set)
        self.detail_box.pack(side="left", fill="both", expand=True)
        detail_scroll.pack(side="right", fill="y")
        self.canvas.create_window(400, 420,
                                  anchor="nw", window=detail_frame)

        # decorative images
        self.canvas.create_image(819, 41, image=load_image("image_2.png"))
        self.canvas.create_image(811, 467, image=load_image("image_3.png"))

        # load & bind
        self.alerts = []
        self.load_alerts()
        self.alert_listbox.bind("<<ListboxSelect>>", self.show_details)

    def load_alerts(self):
        """Fetch alert logs and fill the list."""
        self.alert_listbox.delete(0, END)
        self.alerts = db_manager.get_alert_logs()
        for idx, alert in enumerate(self.alerts, start=1):
            title = alert.split("\n", 1)[0]
            self.alert_listbox.insert(END, f"{idx}. {title}")

    def show_details(self, event):
        sel = self.alert_listbox.curselection()
        if not sel:
            return
        full_log = self.alerts[sel[0]]

        # clear details area
        self.detail_box.delete("1.0", END)

        lines = full_log.strip().splitlines()
        header = lines[0]
        self.detail_box.insert(END, header + "\n\n")

        # extract any "Similarity…" lines
        sim_lines = [ln for ln in lines if re.match(r"^Similarity", ln, re.IGNORECASE)]
        if sim_lines:
            self.detail_box.insert(END, "=== Similarity Index ===\n")
            for ln in sim_lines:
                self.detail_box.insert(END, ln + "\n")
            self.detail_box.insert(END, "\n")

        # old metadata
        old_lines = [ln for ln in lines if ln.startswith("Old ")]
        if old_lines:
            self.detail_box.insert(END, "=== Old Metadata ===\n")
            for ln in old_lines:
                if ln.startswith("Old Size:"):
                    _, raw = ln.split("Old Size:", 1)
                    try:
                        hr = human_readable_size(int(raw.strip()))
                    except:
                        hr = raw.strip() + " B"
                    self.detail_box.insert(END, f"Old Size: {hr}\n")
                else:
                    self.detail_box.insert(END, ln + "\n")
            self.detail_box.insert(END, "\n")

        # new metadata
        new_lines = [ln for ln in lines if ln.startswith("New ")]
        if new_lines:
            self.detail_box.insert(END, "=== New Metadata ===\n")
            for ln in new_lines:
                if ln.startswith("New Size:"):
                    _, raw = ln.split("New Size:", 1)
                    try:
                        hr = human_readable_size(int(raw.strip()))
                    except:
                        hr = raw.strip() + " B"
                    self.detail_box.insert(END, f"New Size: {hr}\n")
                else:
                    self.detail_box.insert(END, ln + "\n")
            self.detail_box.insert(END, "\n")

        # any other remaining lines (e.g. full raw log)
        used = {header} | set(sim_lines) | set(old_lines) | set(new_lines)
        remaining = [ln for ln in lines if ln not in used]
        if remaining:
            self.detail_box.insert(END, "--- Full Log ---\n")
            for ln in remaining:
                self.detail_box.insert(END, ln + "\n")

    def _clear_alerts(self):
        if not self.alerts:
            messagebox.showinfo("No Alerts", "There are no alerts to clear.")
            return
        if messagebox.askyesno("Confirm", "Delete all alerts?"):
            self.alert_listbox.delete(0, END)
            self.detail_box.delete("1.0", END)
            self.alerts.clear()
            db_manager.clear_alert_logs()
            messagebox.showinfo("Cleared", "All alerts have been deleted.")
